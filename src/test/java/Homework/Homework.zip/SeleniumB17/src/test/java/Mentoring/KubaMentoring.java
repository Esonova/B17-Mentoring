package Mentoring;

public class KubaMentoring {

}
